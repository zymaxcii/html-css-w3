If you want to get involved in making Simple.css better, please feel free to submit a pull request with any additions or changed you think would be suitable.

Alternatively, if you're not a coder, or don't want to submit a pull request, feel free to [submit an issue](https://github.com/kevquirk/simple.css/issues).

## Contributing

If you decide to contribute to this project, please edit the `simple.css`, once I merge your change, I will minify it myself.

If you do add contributions, please add verbose commenting so I can understand the rationale for the changes/additions you are proposing.

Thanks again for wanting to contribute to this project!

 -- Kev
